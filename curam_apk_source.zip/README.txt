CURAM GUTALAC V31 Android APK Source

Features:
- Biometric login option on Android APK
- Admin/Skyline backup login still available
- Dashboard item edit remains available
- Editing Current Qty requires biometric authentication
- Other item details can be edited normally

Build with GitHub Actions using the included build-apk.yml.
