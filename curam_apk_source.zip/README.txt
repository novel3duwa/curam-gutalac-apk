CURAM GUTALAC V32 APK TOP BAR FIX

Includes V31 biometric stock edit plus mobile top navigation fix.
