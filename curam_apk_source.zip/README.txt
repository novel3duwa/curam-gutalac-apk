CURAM GUTALAC V27 APK SAFE AREA FIX

Changes:
- The app now starts below the Android status/signal bar area.
- The top header should no longer mix with signal, battery, or notifications.
- Bottom phone menu remains removed from V26.
- Alert/toast messages still appear in the center.

Build the APK using the included builder files.
