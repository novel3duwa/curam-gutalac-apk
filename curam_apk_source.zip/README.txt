CURAM GUTALAC V29 APK source. Gallery-only picture selection and item detail edit option.
