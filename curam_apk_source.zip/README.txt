CURAM GUTALAC V33 Phone APK - Biometric + PC Auto Sync

Features:
- V32 top bar/status bar fix
- V31 biometric login option
- Biometric required for manual stock quantity edit
- Gallery-only picture selection
- Dashboard item edit
- PC Auto Sync panel in Backup / Transfer

Build with GitHub Actions using the included build-apk.yml.
Use pc_sync_server.zip from this package on the PC side.
