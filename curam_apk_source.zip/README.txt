CURAM GUTALAC V32 CODE + PC AUTO SYNC ONLY

This package uses the V32 APK code and adds only the PC Auto Sync panel in Backup / Transfer.

Build with GitHub Actions using curam_apk_source.zip and build-apk.yml.
