CURAM GUTALAC V28 PHOTO PICKER FIX

Changes:
- Delivery picture now has two choices: Take Picture and Choose from Gallery.
- Camera preview/save handling improved for Android WebView.
- If camera capture fails on some phones, use Choose from Gallery after taking a photo with the Camera app.
- V27 safe-area/status-bar fix and middle alert behavior are kept.
